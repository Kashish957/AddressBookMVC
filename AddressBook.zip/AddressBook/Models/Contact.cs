﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MVCAddressBook.Models
{
    public class Contact
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        [MinLength(10, ErrorMessage = "It should be of Atleast 10 digits")]
        public string PhoneNumber { get; set; }
        [Required(ErrorMessage = "Email is required"), EmailAddress]
        public string Email { get; set; }
        [Required]
        public long Landline { get; set; }
        [Required]
        public string Website { get; set; }
        [Required]
        public Address Address { get; set; }
    }
    public class Address
    {
        [Required]
        public string State { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public int PinCode { get; set; }

    }
}

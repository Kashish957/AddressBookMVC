﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MVCAddressBook.Models.DataModel
{
    public class Contact
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required(ErrorMessage = "Email is required"), EmailAddress]
        public string Email { get; set; }
        [Required]
        [MinLength(10, ErrorMessage ="It should be of Atleast 10 digits")]
        public string PhoneNumber { get; set; }
        [Required]
        public long LandLine { get; set; }
        [Required]
        public string Website { get; set; }
        [Required]
        public string Address { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MVCAddressBook.Data;
using MVCAddressBook.Models;
using MVCAddressBook.Services;

namespace MVCAddressBook.Controllers
{
    public class ContactsController : Controller
    {
        private readonly IContactService ContactRepository;
        public ContactsController(IContactService repository)
        {
            ContactRepository = repository;
        }
        public IActionResult Index()
        {
            var contact=ContactRepository.GetContacts().FirstOrDefault();
            if(contact==null)
            {               
                return RedirectToAction(nameof(PostContactForm));
            }
            return RedirectToAction(nameof(GetContactDetails),contact);
        }
        public  IActionResult GetContacts()
        {
            var contacts = ContactRepository.GetContacts();
            return Json(contacts);
        }
        public IActionResult GetContactDetails(int id)
        {
            var contact = ContactRepository.GetContact(id);
            return View(contact);
        }
        public IActionResult DeleteContact(int id)
        {
            var contact = ContactRepository.GetContact(id);
            return View(contact);
        }

        // POST: Contacts/Delete/5
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            ContactRepository.DeleteContact(id);
            return RedirectToAction(nameof(Index));
        }
        // GET: Contacts/PostContactForm
        public IActionResult PostContactForm(int id)
        {
            if (id == 0)
            {
                return View();
            }
            var contact = ContactRepository.GetContact(id);
            return View(contact);
        }

        [HttpPost]
        public IActionResult PostContactForm(Contact contact,int id)
        {
            if (id == 0)
            {
                if (ModelState.IsValid)
                {
                    var contactId = ContactRepository.PostContact(contact, id);
                    return RedirectToAction(nameof(GetContactDetails), new { id = contactId });
                }
                return View("PostContactForm",contact);
            }
           
            if (ModelState.IsValid)
            {
               contact.Id = id;
               var contactId = ContactRepository.PostContact(contact, id);
               return RedirectToAction(nameof(GetContactDetails), new { id = contactId });
            }
            return View("PostContactForm", contact);
        }
    }
}
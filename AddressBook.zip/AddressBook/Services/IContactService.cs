﻿using MVCAddressBook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCAddressBook.Services
{
    public interface IContactService
    {
        List<Contact> GetContacts();
        int PostContact(Contact contact, int id);
        void DeleteContact(int id);

        Contact GetContact(int id);
    }
}

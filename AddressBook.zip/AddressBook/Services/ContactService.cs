﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MVCAddressBook.Data;
using MVCAddressBook.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCAddressBook.Services
{
    public class ContactService : IContactService
    {
        private readonly DatabaseContext Context;
        private readonly IMapper Mapper;
      //  private readonly IConfiguration Config;
        public ContactService(DatabaseContext context, IMapper mapper)
        {
            Context = context;
            Mapper = mapper;
        }
        public List<Contact> GetContacts()
        {
            var contacts = Context.Contacts.ToList();
            return Mapper.Map<List<Contact>>(contacts);
        }
        public int PostContact(Contact contact, int id)
        {
            var postContact = Mapper.Map<Models.DataModel.Contact>(contact);
            if (id == 0)
            {
                Context.Contacts.Add(postContact);
                Context.SaveChanges();
                return postContact.Id;
            }
           
           Context.Update(postContact);
           Context.SaveChanges();
           return id;
        }
        public Contact GetContact(int id)
        {
            if(id==0)
            {
                return null;
            }
            var contact = Context.Contacts.Find(id);
            return Mapper.Map<Contact>(contact);
        }

        public void DeleteContact(int id)
        {
            var deleteContact = new Models.DataModel.Contact()
            {
                Id = id
            };
            Context.Entry(deleteContact).State = EntityState.Deleted;
            Context.SaveChanges();
        }
    }
}
